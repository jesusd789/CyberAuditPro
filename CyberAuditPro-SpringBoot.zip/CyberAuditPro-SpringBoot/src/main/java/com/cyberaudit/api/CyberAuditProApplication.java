package com.cyberaudit.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase de arranque de la aplicacion.
 * Al ejecutar esto, Spring Boot levanta un servidor Tomcat embebido
 * (no hace falta instalar ni configurar Tomcat aparte).
 */
@SpringBootApplication
public class CyberAuditProApplication {

    public static void main(String[] args) {
        SpringApplication.run(CyberAuditProApplication.class, args);
    }
}
